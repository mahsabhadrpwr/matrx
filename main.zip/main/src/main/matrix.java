
package main;
import java.util.Iterator;
import java.util.Scanner;

public class matrix {
	

	public static void main(String [] args) {
		int r=0;
		int c=0;
	
		System.out.print("enter the number of row=");
		Scanner input =new Scanner(System.in);
		r =input.nextInt();
		System.out.print("enter the nember of column=");
		c = input.nextInt();
		int[][] a=new int[r][c];
		int[][] b=new int[r][c];
		int [][] mul=new int[a.length][b[0].length];

		System.out.print("enter the first matrix element=\n");
		
		for(int i=0; i<r;i++)
		{
			for(int j=0;j<c;j++) {
				a[i][j]=input.nextInt();
			}
				
		}
		
		System.out.print("enter the second matrix element=\n");
		
		for(int i=0;i<r;i++) 
		{
		for(int j=0;j<c;j++) {
			b[i][j]=input.nextInt();
			
			}
		}
		System.out.print("multiply of the matrix=\n");
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
				
			
						mul[i][j]=0;
			for(int k=0;k<c;k++) {
				mul[i][j]+=a[i][k]*b[k][j];
				System.out.print(mul[i][j]);
			}
			}
			}
		}
		}
		
	

